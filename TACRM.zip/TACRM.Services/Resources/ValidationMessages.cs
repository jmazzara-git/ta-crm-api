﻿namespace TACRM.Services.Resources
{
	public class ValidationMessages
	{
	}
}